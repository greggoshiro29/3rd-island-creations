# LOVE ME AS I AM — Digital Download Package

Thank you for your purchase! Here's everything included.

## WHAT'S INSIDE

1. **Love-Me-As-I-Am_Workbook_6x9.pdf** — the complete 98-page workbook,
   fully illustrated with watercolour washes and hand-drawn motifs.
   Sized 6" x 9", trimmed to the edge with no bleed marks. This is your
   main file: read it on screen, tablet, or print it.

2. **Love-Me-As-I-Am_PRINTER_FRIENDLY_8.5x11.pdf** — the same workbook on
   US Letter paper with a plain, low-ink layout. Use this one if you plan
   to print at home and don't want to burn through colour ink.

3. **cover-preview.png** — the front cover, if you'd like to see how the
   finished book looks.

## HOW TO PRINT

**Recommended:** print the **printer-friendly 8.5" x 11"** version —
it uses a fraction of the ink and reads beautifully on plain paper.

If you print the illustrated 6" x 9" version, choose:

- **Actual size / 100%** — NOT "fit to page". Fit-to-page shrinks
  everything by about 3–4%; harmless, but actual size is cleanest.
- **Two-sided / duplex** (flip on long edge) — saves paper and gives you
  a real booklet.
- **Colour** if you like the watercolour backgrounds, but black & white
  is perfectly readable.

The illustrated version is designed to the very edge of the page
(full bleed), so a home printer will trim a sliver of the background
away. That's intentional and nothing important sits in that margin.
For a print-shop copy, hand them the 6" x 9" file.

## HOW TO USE THE WORKBOOK

This is a book you DO, not just read. Get a pen and work through one
chapter at a time:

1. Read the advice.
2. Fill in the blanks — there are no wrong answers.
3. Take the "Little Step" at the end of each chapter.
4. Keep writing on the journal pages.
5. Tear out the affirmation pages and keep them where you'll see them.

You can also type into it: open the PDF in any PDF app that supports
annotations (Preview on Mac, Adobe Acrobat, GoodNotes, Notability).

## IMPORTANT

This workbook is for education and support only. It is not professional
or medical advice. If you or your child are in crisis, contact The Trevor
Project (US): call or text **1-866-488-7386**, or reach a qualified
counsellor. Support resources are listed inside the book.

## THANK YOU

Your child isn't a problem to solve — they're a person to love. We hope
this helps you say the words that want to be said.

*This is a digital product. All sales are final. No physical item ships.*

— 3rd Island Creations
   3rdislandcreations.com
