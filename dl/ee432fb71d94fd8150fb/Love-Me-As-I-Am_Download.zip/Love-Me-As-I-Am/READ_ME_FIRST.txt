# LOVE ME AS I AM — Digital Download Package

Thank you so much for your purchase! Here's everything included.

## WHAT'S INSIDE

1. **Love-Me-As-I-Am_Workbook_Letter_8.5x11.pdf** — the complete 98-page
   illustrated workbook on **US Letter (8.5" x 11")**. This is your main
   file and the one most people print. Read it on screen or print it.

2. **Love-Me-As-I-Am_Workbook_6x9.pdf** — the same 98 pages at **6" x 9"**
   trade size, trimmed to the edge. Lovely on a tablet, or take it to a
   print shop and have them bind you a real book.

3. **Love-Me-As-I-Am_PRINTER_FRIENDLY_8.5x11.pdf** — a plain, low-ink
   Letter edition of the same workbook. Use this one if you want to print
   at home without burning through colour ink.

4. **Love-Me-As-I-Am_Fillable.pdf** — a version you can TYPE into. Open it
   in Adobe Acrobat, Preview, GoodNotes or Notability and fill in the boxes
   on screen instead of by hand.

5. **cover-preview.png** — the finished front cover.

## HOW TO PRINT

Only need one copy? Use the **printer-friendly** file — it uses a fraction
of the ink and reads beautifully on plain paper.

Printing the illustrated version? Set your printer to:

- **Actual size / 100%** — NOT "fit to page". Fit-to-page shrinks
  everything by about 3-4%; harmless, but actual size is cleanest.
- **Two-sided / duplex** (flip on long edge) — saves paper and gives you
  a real booklet you can fold and bind.
- **Colour** if you like the watercolour backgrounds. It prints fine in
  black & white too.

The illustrated pages are designed to the very edge (full bleed), so a
home printer will trim a sliver of the background away. That's on purpose,
and nothing important sits in that margin.

## HOW TO USE THE WORKBOOK

This is a book you DO, not just read. Get a pen and work through one
chapter at a time:

1. Read the advice.
2. Fill in the blanks — there are no wrong answers.
3. Take the "Little Step" at the end of each chapter.
4. Keep writing on the journal pages.
5. Tear out the affirmation pages and keep them where you'll see them.

## IMPORTANT

This workbook is for education and support only. It is not professional
or medical advice. If you or your child are in crisis, contact The Trevor
Project (US): call or text **1-866-488-7386**, or reach a qualified
counsellor. Support resources are listed inside the book.

## THANK YOU

Your child isn't a problem to solve — they're a person to love. We hope
this helps you say the words that want to be said.

*This is a digital product. All sales are final. No physical item ships.*

— 3rd Island Creations
   3rdislandcreations.com
